﻿using System.Drawing;
using System.Windows.Forms;

namespace FNFDataManager.Assets
{
    public partial class UpArrow : UserControl
    {
        public UpArrow()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

        }
    }
}